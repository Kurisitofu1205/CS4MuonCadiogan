/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/javafx/FXMain.java to edit this template
 */
package ex11muoncadioganchristopherandrew;

import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.FlowPane;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.Text;
import javafx.stage.Stage;

public class Ex11muoncadioganchristopherandrew extends Application {
    
    @Override
    public void start(Stage primaryStage) {
        new Subject("Math","math.png",4,1.75);
        new Subject("Biology","biology.png",3,2.);
        new Subject("Chemistry","chemistry.png",3,1.5);
        new Subject("Computer Science","computer science.png",1,1.25);
        new Subject("Physics","physics.png",5,1.0);
        
        Subject display;
        
        primaryStage.setTitle("Subject Display");

        /* Setting a layout */
        FlowPane root = new FlowPane();
        Scene scene = new Scene(root, 450, 450);
        primaryStage.setScene(scene);
        
        /* Adding an image */
        ImageView icon = new ImageView();
        Image img = new Image(Ex11muoncadioganchristopherandrew.class.getResourceAsStream("imgs/" + display.getImgFileName()));
        icon.setImage(img);
        root.getChildren().add(icon);
        
        /* Adding text */
        Text name = new Text(display.getName());
        root.getChildren().add(name);
        
        Text units = new Text(Double.toString(display.getUnits()));
        root.getChildren().add(units);
        
        Text grades = new Text(Double.toString(display.getGrade()));
        root.getChildren().add(grades);
        
        /* Adding a button */
        Button button = new Button("Next");
        root.getChildren().add(button);
        
        primaryStage.show();
    }

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        launch(args);
    }
    
}
